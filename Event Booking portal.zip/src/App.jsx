 import { useState } from "react";
import "./App.css";

export default function App() {
  const [events, setEvents] = useState([
    { id: 1, name: "Tech Conference", date: "2025-02-10", seats: 50 },
    { id: 2, name: "Music Concert", date: "2025-03-05", seats: 100 },
    { id: 3, name: "Startup Meetup", date: "2025-04-01", seats: 30 }
  ]);

  const [bookings, setBookings] = useState([]);

  const handleBook = (id) => {
    setEvents(events.map(e =>
      e.id === id && e.seats > 0 ? { ...e, seats: e.seats - 1 } : e
    ));

    const event = events.find(e => e.id === id);
    if (event && event.seats > 0) {
      setBookings([...bookings, event.name]);
    }
  };

  return (
    <div className="app">
      <h1>Event Booking System</h1>

      <div className="events">
        {events.map(event => (
          <div className="card" key={event.id}>
            <h2>{event.name}</h2>
            <p><strong>Date:</strong> {event.date}</p>
            <p><strong>Seats Left:</strong> {event.seats}</p>

            <button
              disabled={event.seats === 0}
              onClick={() => handleBook(event.id)}
            >
              {event.seats === 0 ? "Sold Out" : "Book Now"}
            </button>
          </div>
        ))}
      </div>

      <div className="bookings">
        <h2>My Bookings</h2>
        {bookings.length === 0 ? (
          <p>No bookings yet</p>
        ) : (
          <ul>
            {bookings.map((b, i) => (
              <li key={i}>{b}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
